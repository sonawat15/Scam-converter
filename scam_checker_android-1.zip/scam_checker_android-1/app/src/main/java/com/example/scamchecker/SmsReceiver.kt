package com.example.scamchecker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Checks every incoming SMS and warns you only if it looks risky. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val r = ScamEngine.analyze(body)
        if (r.label != "Safe") Alerts.notify(c, "SMS", body, r)
    }
}
