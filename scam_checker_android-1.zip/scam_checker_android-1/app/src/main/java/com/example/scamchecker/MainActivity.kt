package com.example.scamchecker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var out: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        col.addView(TextView(this).apply {
            text = "Scam Checker\nChecks messages on this phone. The app has no internet permission, so nothing leaves your phone.\n"
            textSize = 18f
        })
        btn("1. Allow SMS access") {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Allow WhatsApp / email alerts (notification access)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Scan my last 50 SMS") { scan() }
        btn("Call 1930 - Cyber Crime Helpline") { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1930"))) }
        out = TextView(this).apply { setPadding(0, 30, 0, 0) }
        col.addView(out)
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun scan() {
        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) { out.text = "Tap step 1 first."; return }
        val sb = StringBuilder()
        contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")?.use { c ->
            var n = 0
            while (c.moveToNext() && n < 50) {
                n++
                val body = c.getString(1) ?: ""
                val r = ScamEngine.analyze(body)
                if (r.label != "Safe") sb.append(if (r.label == "High") "RED " else "YELLOW ")
                    .append(c.getString(0)).append(": ").append(body.take(80)).append("\n  -> ")
                    .append(r.reasons.take(2).joinToString("; ")).append("\n\n")
            }
        }
        out.text = if (sb.isEmpty()) "No scam signs in your last 50 SMS." else sb.toString()
    }
}
