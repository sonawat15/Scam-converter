package com.example.scamchecker

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** With notification access, checks message previews from WhatsApp, Gmail, Outlook and Messages. */
class NotifyListener : NotificationListenerService() {
    private val apps = mapOf(
        "com.whatsapp" to "WhatsApp", "com.whatsapp.w4b" to "WhatsApp Business",
        "com.google.android.gm" to "Gmail", "com.microsoft.office.outlook" to "Outlook",
        "com.google.android.apps.messaging" to "Messages"
    )
    private val seen = LinkedHashSet<Int>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val src = apps[sbn.packageName] ?: return
        val e = sbn.notification.extras
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        if (!seen.add(text.hashCode())) return
        if (seen.size > 200) seen.remove(seen.first())
        val r = ScamEngine.analyze(text)
        if (r.label != "Safe") Alerts.notify(this, src, text, r)
    }
}
