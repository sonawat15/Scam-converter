package com.example.scamchecker

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri

object Alerts {
    private const val CH = "scam"
    fun notify(ctx: Context, source: String, text: String, r: ScamEngine.Result) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Scam alerts", NotificationManager.IMPORTANCE_HIGH))
        val title = (if (r.label == "High") "⚠ Scam alert" else "Be careful") + " ($source)"
        val body = r.reasons.take(3).joinToString("; ") + ". Do not click, pay or share any OTP. If money is lost, call 1930."
        val pi = PendingIntent.getActivity(ctx, 0, Intent(Intent.ACTION_DIAL, Uri.parse("tel:1930")), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(text.hashCode(), Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(pi).setAutoCancel(true).build())
    }
}
