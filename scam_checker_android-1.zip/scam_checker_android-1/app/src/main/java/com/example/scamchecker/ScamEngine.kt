package com.example.scamchecker

import java.net.URI
import kotlin.math.max
import kotlin.math.min

/** Kotlin port of the web app's detection logic (upi_scam_detector-6.html). */
object ScamEngine {
    data class Result(val score: Int, val label: String, val reasons: List<String>, val debit: Boolean)

    private val I = RegexOption.IGNORE_CASE
    private class Rule(val re: Regex, val pts: Int, val why: String)

    private val RULES = listOf(
        Rule(Regex("""kyc|केवाईसी|aadhaar|aadhar|आधार|pan\s*(card)?\s*(update|link|expire|block)|(account|khata|खाता)[^.\n]{0,30}(block|band|suspend|freez|बंद|ब्लॉक)""", I), 30, "Fake bank warning: banks never block accounts or update KYC through a link"),
        Rule(Regex("""urgent|immediately|turant|abhi|jaldi|within \d+ ?(hours?|hrs|ghante|minutes?)|\d+ ?(hours?|ghante)|last chance|expires? (today|soon)|तुरंत|अभी|जल्दी|आखिरी मौका""", I), 20, "Rushing you"),
        Rule(Regex("""refund|cashback|reward|lottery|lucky|jeet(a|e|ne)?|inaam|prize|free gift|winner|रिफंड|इनाम|लॉटरी|जीत""", I), 20, "Free-money bait"),
        Rule(Regex("""\b(otp|pin|cvv|password|upi pin)\b|ओटीपी|पिन""", I), 25, "Asks for OTP / PIN"),
        Rule(Regex("""collect request|enter (your )?(upi )?pin to receive|accept (the )?(request|collect)|approve (the )?request|to receive money""", I), 30, "Money-taking trick: you never type a PIN to receive money"),
        Rule(Regex("""digital arrest|cbi|police|customs|narcotics|\bed officer|warrant|court notice|cyber ?cell|सीबीआई|पुलिस|गिरफ्तार""", I), 30, "Fake police / officer"),
        Rule(Regex("""\.apk\b|install (this |the )?app|anydesk|teamviewer|quicksupport|screen ?share""", I), 30, "Asks you to install an app"),
        Rule(Regex("""(processing|registration|release|clearance|delivery|customs) (fee|charge)s?|pay .{0,25}(to (claim|receive|release))|फीस|फ़ीस""", I), 25, "Asks for a fee first"),
        Rule(Regex("""dear (customer|user|sir|madam)|प्रिय (ग्राहक|उपयोगकर्ता)""", I), 5, "No name used"),
        Rule(Regex("""(call|contact|whatsapp|dial|reach)[^.\n]{0,30}(\+?91[-\s]?)?[6-9]\d{9}\b""", I), 30, "Personal mobile number to call")
    )

    private val SAFEPH = Regex("""\b(?:do not|don't|dont|never)\s+(?:share|disclose|tell|give)\b[^.,;\n]{0,50}""", I)
    private val LEGIT = listOf(
        Regex("""\b(debited|credited|spent|withdrawn|deposited)\b[^.\n]{0,50}(a/c|acct|account|card|upi)|a/c\s*(no\.?\s*)?[x*]+\d{3,4}|upi (ref|txn)[^.\n]{0,12}\d{6,}|avl\.? ?bal|available balance""", I) to 25,
        Regex("""contract note|trade confirmation|funds (added|withdrawn|credited)|client id|order (executed|placed)|demat""", I) to 15,
        Regex("""\botp\b[^.\n]{0,25}\b\d{4,8}\b|\b\d{4,8}\b[^.\n]{0,25}\botp\b|valid for \d+ ?min""", I) to 20,
        Regex("""do not share|never share|if (this was )?not you|wasn'?t you|not done by you""", I) to 10
    )
    private val ASK = Regex("""\b(share|send|tell|give|forward|provide|read out)\b[^.\n]{0,30}\b(otp|pin|cvv)\b""", I)
    private val BANKRE = Regex("""\b(sbi|state bank|hdfc|icici|axis|kotak|pnb|punjab national|baroda|canara|union bank|bank of india|indian bank|idbi|yes bank|indusind|idfc|federal|paytm|phonepe|zerodha|groww|upstox|npci)\b""", I)
    private val HELPRE = Regex("""not you|not done by you|wasn'?t you|1930|1800[\s-]?\d|\bcall\b|\bcontact\b""", I)
    private val URLRE = Regex("""(?:https?|upi)://[^\s]+|\b(?:bit\.ly|tinyurl\.com|t\.co|cutt\.ly|rb\.gy|is\.gd)/[^\s]*|\b[\w-]+(?:\.[\w-]+)*\.(?:xyz|top|click|link|vip|site|online|icu|buzz|cfd|sbs)\b[^\s]*""", I)

    private val OFFICIAL = mapOf(
        "sbi" to listOf("sbi.co.in", "onlinesbi.sbi", "sbi.bank.in", "sbicard.com", "sbilife.co.in"),
        "hdfc" to listOf("hdfcbank.com"), "icici" to listOf("icicibank.com"), "axis" to listOf("axisbank.com"),
        "kotak" to listOf("kotak.com"), "zerodha" to listOf("zerodha.com"), "groww" to listOf("groww.in"),
        "upstox" to listOf("upstox.com"), "paytm" to listOf("paytm.com"), "phonepe" to listOf("phonepe.com"),
        "npci" to listOf("npci.org.in"), "irctc" to listOf("irctc.co.in"), "uidai" to listOf("uidai.gov.in"),
        "incometax" to listOf("incometax.gov.in"), "amazon" to listOf("amazon.in", "amazon.com"),
        "flipkart" to listOf("flipkart.com"), "bhim" to listOf("bhimupi.org.in")
    )
    private val OTHER_BANKS = listOf("pnbindia.in", "bankofbaroda.in", "canarabank.com", "unionbankofindia.co.in", "bankofindia.co.in", "indianbank.in", "idbibank.in", "yesbank.in", "indusind.com", "idfcfirstbank.com", "centralbankofindia.co.in", "ucobank.com", "iob.in", "bankofmaharashtra.in", "federalbank.co.in", "ippbonline.com")
    private val TRUSTED = OFFICIAL.values.flatten() + OTHER_BANKS
    private val TYPO = listOf("hdfcbank", "icicibank", "axisbank", "kotak", "paytm", "phonepe", "zerodha", "groww", "upstox", "canarabank", "bankofbaroda", "unionbank", "npci", "irctc", "uidai", "amazon", "flipkart", "paypal", "incometax")

    private fun hostOf(u: String): String = try {
        URI(if (Regex("^https?://", I).containsMatchIn(u)) u else "http://$u").host?.lowercase()?.trimEnd('.') ?: ""
    } catch (e: Exception) { "" }

    private fun trusted(h: String) = h.isNotEmpty() &&
        (Regex("""\.(bank\.in|gov\.in|nic\.in)$""").containsMatchIn(h) || TRUSTED.any { h == it || h.endsWith(".$it") })

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { i -> IntArray(b.length + 1) { j -> if (i == 0) j else if (j == 0) i else 0 } }
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun urlChecks(u: String): List<Pair<Int, String>> {
        val o = mutableListOf<Pair<Int, String>>()
        if (u.startsWith("upi://", true)) {
            o += 20 to "Payment link: opening it can start a payment"
            if (u.contains("am=")) o += 10 to "Amount already filled in the payment link"
            return o
        }
        val h = hostOf(u)
        if (h.isEmpty()) return o
        if (Regex("""^\d{1,3}(\.\d{1,3}){3}$""").matches(h)) o += 30 to "Link is a number string, not a name"
        if (Regex("""^(bit\.ly|tinyurl\.com|t\.co|cutt\.ly|rb\.gy|is\.gd|goo\.gl|shorturl\.at)$""").matches(h)) o += 20 to "Short link hides the real website"
        if (Regex("""\.(xyz|top|click|link|vip|site|online|icu|buzz|cfd|sbs|live|cf|tk|gq|ml|work|support)$""").containsMatchIn(h)) o += 20 to "Website ending often used by fake sites"
        if (u.substringAfter("://").substringBefore("/").contains("@")) o += 25 to "Disguised link (text before @ is a trick)"
        if (h.contains("xn--")) o += 25 to "Look-alike letters in website name"
        if (u.startsWith("http:", true)) o += 10 to "Not a secure (https) link"
        val n = h.replace('0', 'o').replace('1', 'l').replace('3', 'e')
        var fb = false
        for ((b, ds) in OFFICIAL) {
            if (n.contains(b)) {
                if (ds.none { h == it || h.endsWith(".$it") }) { o += 30 to "Fake ${b.uppercase()} website (real one is ${ds[0]})"; fb = true }
                break
            }
        }
        if (!trusted(h)) {
            val lab = h.split(".")
            if (h.count { it == '-' } >= 2) o += 12 to "Too many hyphens in website name"
            val tb = lab.flatMap { l -> TYPO.filter { b -> l != b && l.length >= 4 && lev(l, b) in 1..2 } }.firstOrNull()
            if (tb != null && !fb) o += 30 to "Looks like a misspelt \"$tb\""
            if (Regex("verify|secure|update|confirm|unlock|suspend|kyc|reactivat").containsMatchIn(h)) {
                o += 12 to "Pressure words in website name"
                if (fb) o += 15 to "Bank name + 'verify' trick"
            }
            if (u.contains("login", true) && lab.size > 3) o += 10 to "Unusual number of sub-domains"
        }
        return o
    }

    fun analyze(text: String): Result {
        var score = 0
        val reasons = mutableListOf<String>()
        val hit = BooleanArray(RULES.size)
        val mt = SAFEPH.replace(text) { " ".repeat(it.value.length) }
        RULES.forEachIndexed { i, r -> if (r.re.containsMatchIn(mt)) { score += r.pts; hit[i] = true; reasons += r.why } }
        var bad = false
        var good = false
        for (m in URLRE.findAll(text)) {
            val u = m.value.trimEnd('.', ',', ')', ';')
            val c = urlChecks(u)
            if (c.isNotEmpty()) { bad = true; for ((p, w) in c) { score += p; reasons += "$w: $u" } }
            else if (trusted(hostOf(u))) good = true
        }
        if (hit[3] && (hit[1] || hit[0])) { score += 10; reasons += "Very dangerous mix: asking for OTP while rushing you" }
        // Real banks send an alert once; the same long line 3+ times is a copy-pasted fake.
        val dup = text.split(Regex("\n+")).map { it.trim() }.filter { it.length >= 20 }
            .groupingBy { it }.eachCount().values.any { it >= 3 }
        if (dup) { score += 40; reasons += "Same alert repeated: a real bank sends an alert once" }
        if ((hit[4] || hit[5] || hit[6] || hit[7]) && hit.count { it } >= 2) score = max(score, 60)
        val strong = bad || dup || hit[0] || hit[2] || hit[4] || hit[5] || hit[6] || hit[7] || hit[9] || ASK.containsMatchIn(mt)
        if (!strong) {
            var legit = LEGIT.filter { it.first.containsMatchIn(text) }.sumOf { it.second }
            if (good) legit += 20
            score = max(0, score - min(legit, 50))
        }
        val deb = LEGIT[0].first.containsMatchIn(text)
        if (deb && !strong) {
            if (Regex("\\b(debited|credited)\\b", I).findAll(text).count() >= 2) { score += 15; reasons += "Alert repeated in one message" }
            if (!BANKRE.containsMatchIn(text) && !HELPRE.containsMatchIn(text)) { score = max(score, 30); reasons += "Debit alert with no bank name and no help line" }
        }
        score = min(score, 100)
        return Result(score, if (score < 25) "Safe" else if (score < 60) "Suspicious" else "High", reasons, deb)
    }
}
